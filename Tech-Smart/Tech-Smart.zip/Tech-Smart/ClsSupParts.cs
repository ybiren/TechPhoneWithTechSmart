﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tech_Smart
{
    class ClsSupParts
    {
        public int unitCode;
        public string desc_ = String.Empty;
        public string code = String.Empty;
        public string unit = String.Empty;
        public string quantity = String.Empty;
    }
}
