﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tech_Smart
{
    public class ClsUnitHandling
    {
      public int unitCode = -1;
      public int handlingCode = -1;
      public string handlingDesc = String.Empty;
      public Int16 isDone = -1;
      public string remarks = String.Empty;
    }
}
