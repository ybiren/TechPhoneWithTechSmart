﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tech_Smart
{
    public class ClsParts
    {
        public string op = String.Empty;
        public string code = String.Empty;
        public string desc_ = String.Empty;
        public string unit = String.Empty;
        public string barcode = String.Empty;
        public string source = String.Empty;
        public string status = String.Empty;
    }
}
