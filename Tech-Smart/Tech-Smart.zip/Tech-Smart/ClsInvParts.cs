﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tech_Smart
{
    public class ClsInvParts
    {
        public string callCode = String.Empty; 
        public string partCode = String.Empty;
        public string partDesc = String.Empty;
        public string partUnit = String.Empty;
        public string partQuantity = String.Empty;
    }
}
