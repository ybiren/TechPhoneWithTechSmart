﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tech_Smart
{
    public class ClsInv
    {
    public double dt;
    public string siteName;
    public string address;
    public string  custName;
    public string dischargeArea;
    public string contactName;
    public string contactPhone;
    public string contactMobile;
    public int quantity;
    public string remarks;
    public string signerName;
    public string signerRole;
    public string signEmail;
    public string signRemarks;
    public string signPic;
    public string weigeCertNum;
    public string weigeRemarks;
    public string weight;
    public int numImages_erPic;
    public int numImages_erSnap;
    public int numImages_wgPic;
    public int numImages_wgSnap;
    public string numExecRep;
    }
}
