﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tech_Smart
{
    public class ClsUnitType
    {
        public int code = 0;
        public string txt = String.Empty;
    }
}